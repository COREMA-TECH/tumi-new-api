import {GraphQLString} from 'graphql';

const punchesCSVFields = {
    path: {
        type: GraphQLString
    },
};

export default punchesCSVFields;